Same tutoriel as https://cryptorobotfr.github.io/HebergerSonBotDeTradingTuto/  

/!\ This tutoriel is on Binance and it will take for the tradding all part of your 2 coins in thes exemples USDT et EGLD coin
Only difference is you have to copy paste this file #1binanceEGLD.py and install another package :  
> pip install python-binance
