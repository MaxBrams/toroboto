To run the live DCA on your server, install all packages (ccxt for ftx and python-binance for binance)

Then create your file .py

And in the crontab type: 0 0 * * 1 your_file.py
