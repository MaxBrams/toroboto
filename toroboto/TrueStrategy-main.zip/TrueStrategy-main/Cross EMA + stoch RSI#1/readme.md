This is the repo for TrueStrategy#1  
If you want to run this bot on ETH USD on FTX, you juste have to execute the file #1FTX.py every hour  
>python #1FTX.py
